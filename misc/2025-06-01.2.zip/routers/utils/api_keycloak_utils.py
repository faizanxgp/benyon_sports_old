from fastapi import HTTPException

from routers.utils.misc_keycloak_utils import *
from routers.utils.keycloak_vars import *


async def create_user(payload, access_token=None):
    try:
        headers, _ = await obtain_headers(access_token)
        if role := payload.get("role"):
            del payload["role"]
        async with httpx.AsyncClient() as client:
            response = await client.post(base_url + ep_create_user, json=payload, headers=headers)
        
        if response.status_code not in [200, 201, 204]:
            raise HTTPException(status_code=response.status_code, detail=response.text)
        
        if not role: return response
        
        username = payload.get("username")
        user_id = (await retrieve_user_details(username)).json()[0].get("id")
        role_id = (await get_client_role(role)).json().get("id")
        role_payload = [{
            "id": role_id,
            "name": role
            }]
        role_response = await assign_client_role(role_payload, user_id)
        
        return role_response
    except Exception as e:
        raise e from e


async def assign_client_role(payload, user_id: str, access_token=None):
    headers, _ = await obtain_headers()
    async with httpx.AsyncClient() as client:
        response = await client.post(
            base_url + ep_assign_client_role.replace("[ENTER_USER_ID]", user_id), 
            json=payload, headers=headers
            )

    return response


async def remove_client_role(payload, user_id: str, access_token=None):
    headers, _ = await obtain_headers()
    async with httpx.AsyncClient() as client:
        response = await client.request("DELETE",
            base_url + ep_assign_client_role.replace("[ENTER_USER_ID]", user_id), 
            json=payload, headers=headers
            )

    return response


async def retrieve_user_details(username, access_token=None):
    try:
        headers, _ = await obtain_headers(access_token)
        query_params = {
        "username": username,
        "exact": True
        }
        async with httpx.AsyncClient() as client:
            response = await client.get(base_url + ep_retrieve_user, params=query_params, headers=headers)
        return response
    except Exception as e:
        raise e from e


async def reset_password(payload, user_id, access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.put(
            base_url + ep_reset_password.replace("[ENTER_USER_ID]", user_id), 
            json=payload, headers=headers
            )

    return response


async def forgot_password(user_id, access_token=None):
    headers, _ = await obtain_headers(access_token)
    payload = ["UPDATE_PASSWORD"]
    async with httpx.AsyncClient() as client:
        response = await client.put(
            base_url + ep_forgot_password.replace("[ENTER_USER_ID]", user_id), 
            json=payload, headers=headers
            )

    return response


async def update_user_details(payload, user_id, access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.put(
            base_url + ep_update_user_details.replace("[ENTER_USER_ID]", user_id), 
            json=payload, headers=headers
            )

    return response


async def logout_user(user_id, access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.post(
            base_url + ep_logout_user.replace("[ENTER_USER_ID]", user_id), 
            headers=headers
            )

    return response


async def users_status(access_token=None):
    all_users = (await get_all_users()).json()
    user_ids = [user.get("id") for user in all_users]
    
    status_details = {}
    for id in user_ids:
        active_sessions = (await check_user_active(id)).json()
        status_details[id] = "active" if (len(active_sessions)>0) else "inactive"
    
    
    return status_details