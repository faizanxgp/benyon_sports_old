import jwt
import json
import time
import httpx

from functools import wraps
from decouple import Config, RepositoryEnv
from fastapi import HTTPException, Request, WebSocket
from keycloak import KeycloakOpenID
from jwcrypto.jwt import JWTExpired
from jwcrypto.jws import InvalidJWSObject, InvalidJWSSignature
from datetime import datetime

from routers.utils.keycloak_vars import *


async def obtain_access_token():
    access_token_payload = {
        "grant_type":"client_credentials",
        "client_id":backend_client_name,
        "scope":"openid",
        "client_secret":backend_client_secret
    }
    token_url = base_url + ep_access_token
    async with httpx.AsyncClient() as client:
        token_response = await client.post(token_url, data=access_token_payload)
        token_response.raise_for_status()  # Optional: raises exception for HTTP 4xx/5xx
        
    access_token = token_response.json()["access_token"]
    return access_token


async def obtain_headers(access_token=None):
    if not access_token: access_token = await obtain_access_token()
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    return headers, access_token


async def check_user_active(user_id, access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.get(
            base_url + ep_check_user_active.replace("[ENTER_USER_ID]", user_id), 
            headers=headers
            )

    return response


async def get_all_users(access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.get(
            base_url + ep_get_all_users, 
            headers=headers
            )

    return response


async def get_client_role(role: str, access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.get(
            base_url + ep_get_client_role.replace("[ENTER_ROLE]", role), 
            headers=headers
            )

    return response


async def delete_user(user_id, access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.delete(base_url + ep_delete_user + user_id, headers=headers)

    return response


async def create_user_policy(payload, access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.post(base_url + ep_create_user_policy, json=payload, headers=headers)

    return response


async def retrieve_user_policy(username, access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.get(base_url + ep_retrieve_policy, headers=headers)

    policy = None
    details = response.json()
    for detail in details:
        if detail["name"] == f"user_{username}":
            policy = detail
            break
    return policy


async def delete_user_policy(policy_id, access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.delete(base_url + ep_delete_user_policy + policy_id, headers=headers)

    return response


async def create_resource(payload, access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.post(base_url + ep_create_resource_url, json=payload, headers=headers)

    return response


async def retrieve_resource(resource_name, access_token=None):
    headers, _ = await obtain_headers(access_token)
    query_params = {
    "name": resource_name,
    "exact": True
    }
    async with httpx.AsyncClient() as client:
        response = await client.get(base_url + ep_retrieve_resource, params=query_params, headers=headers)

    resource_id = response.json()
    return resource_id[0] if resource_id else None


async def delete_resource(resource_id, access_token=None):
    headers, _ = await obtain_headers(access_token)
    async with httpx.AsyncClient() as client:
        response = await client.delete(base_url + ep_delete_resource + resource_id, headers=headers)

    return response
